package com.sails.QR;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class QrApplicationTests {

	@Test
	void contextLoads() {
	}

}
